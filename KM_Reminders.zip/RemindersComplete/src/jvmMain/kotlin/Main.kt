import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Check
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.platform.Font
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogState
import androidx.compose.ui.window.DialogWindow
import androidx.compose.ui.window.singleWindowApplication
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.Serializer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

// Fonts
val latoFont = FontFamily(Font("fonts/Lato-Black.ttf"))

// Main Colours
val maincolour = 0xFF800080
val backgroundcolour = 0xFFfffff2
val accentcolour = 0xFFA100A1

// Basic Colours
val blackcolour = 0xFF000000
val whitecolour = 0xFFFFFFFF
val greycolour = 0xFF808080

// Button Colours
val confirmbutton = 0xFF50C878
val cancelbutton = 0xFFFF0000
val mainbutton = 0xFF63CEE6

// Text Field Colours
val truefocusedcolour = 0xFF7621F0
val trueunfocusedcolour = 0xFF808080
val falsefocusedcolour = 0xFFD60000
val falseunfocusedcolour = 0xFFFF0000

// Saving/Loading File Path
val homeFolder = System.getenv("HOMEPATH")
val remindersDataFilePath = homeFolder + "/tasks.json"
val completedDataFilePath = homeFolder + "/completedtasks.json"

// LocalDate Formatter
val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")

// Enables serialization of the LocalDate data type
@Serializer(forClass = LocalDate::class)
object DateSerializer : KSerializer<LocalDate> {
    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE

    override fun serialize(encoder: Encoder, value: LocalDate) {
        encoder.encodeString(value.format(formatter))
    }

    override fun deserialize(decoder: Decoder): LocalDate {
        return LocalDate.parse(decoder.decodeString(), formatter)
    }
}

// Defines all tasks/reminders with a name, description and a due date
@Serializable
data class Task(
    val taskname: String,
    val taskdescription: String,
    @Serializable(with = DateSerializer::class)
    val taskdate: LocalDate
) {
    override fun toString(): String {
        return "$taskname , $taskdescription, ${taskdate.format(formatter)}"
    }
}

// List of all reminders/tasks
val allReminders = mutableStateListOf<Task>()
val completedReminders = mutableStateListOf<Task>()

// This function gets all entered date values, checks if they are valid then combines them into a full dd/mm/yyyy format to be passed into a Task
fun checkDate(day: String, month: String, year: String): LocalDate {
    if (day.toInt() in 1..31) {
        if (month.toInt() in 1..12) {
            val alldates = mutableListOf<String>()

            alldates.add("$day".padStart(2, '0'))
            alldates.add("$month".padStart(2, '0'))
            alldates.add(year)

            val datestring = alldates.joinToString(".")

            val newtaskdate = LocalDate.parse("$datestring", formatter)

            return newtaskdate
        } else {
            throw Exception("Date given is invalid")
        }
    } else {
        throw Exception("Date given is invalid")
    }
}

// Dialog Window State Checks
var isAddReminderDialogOpen by mutableStateOf(false)

@Composable
fun App() {
    // Variable enables scrolling
    val scrollState = rememberScrollState()

    // List of reminders to display
    var reminderList by remember { mutableStateOf(allReminders) }

    // Whole window
    MaterialTheme(
        typography = Typography(defaultFontFamily = latoFont)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(color = Color(backgroundcolour))
                .padding(10.dp, 0.dp, 10.dp, 0.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1.0f),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(maincolour)),

                    onClick = {
                        reminderList = allReminders
                    }
                ) {
                    Text("Reminders (${allReminders.count()})", color = Color(whitecolour))
                }
                Button(
                    modifier = Modifier.weight(1.0f),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(confirmbutton)),

                    onClick = {
                        reminderList = completedReminders
                    }
                ) {
                    Text("Completed (${completedReminders.count()})", color = Color(whitecolour))
                }
            }
            // Reminders
            Column(
                modifier = Modifier.weight(0.8f).verticalScroll(state = scrollState),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                // Gives each reminder in allReminders a block to display name, description, due date and buttons
                for (reminder in reminderList.sortedBy { task -> task.taskdate }) {
                    val currentdate = LocalDate.now()
                    val reminderdate = reminder.taskdate

                    if (currentdate >= reminderdate) {
                        ReminderRow(reminder, true)
                    } else {
                        ReminderRow(reminder, false)
                    }
                }
            }
            Row(

            ) {
                Button(
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(confirmbutton)),
                    modifier = Modifier.weight(1.0f),
                    onClick = { isAddReminderDialogOpen = true }
                ) {
                    Text(text = "Create a Reminder", color = Color.White)
                }
            }
        }
        if (isAddReminderDialogOpen) {
            addNewReminderDialog()
        }
    }
}

// ReminderRow makes a block of information for each task, displaying their name, description and due date, alongside an edit and delete task button
// isItToday checks if the task is due today, if so the reminder will change colour
@Composable
fun ReminderRow(task: Task, isItToday: Boolean) {
    var mainremindercolour: Long
    var accentremindercolour: Long

    // If reminder is in allReminders, the colours used will be purple if the task isn't due today and red if it is
    // Else, the reminder is in completedReminders, so the colours used will be green
    if (allReminders.contains(task)) {
        if (isItToday == true) {
            mainremindercolour = 0xFFD60000
            accentremindercolour = 0xFFFF0000
        } else {
            mainremindercolour = 0xFF800080
            accentremindercolour = 0xFFA100A1
        }
    } else {
        mainremindercolour = 0xFF45AD68
        accentremindercolour = 0xFF50C878
    }

    Row(
        modifier = Modifier.fillMaxWidth().background(color = Color(whitecolour), shape = RoundedCornerShape(20))
            .border(width = 3.5.dp, shape = RoundedCornerShape(20), color = Color(mainremindercolour)).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        var isAlterReminderDialogOpen by remember { mutableStateOf(false) }
        var alterStatusType by remember { mutableStateOf("complete") }

        var isEditReminderDialogOpen by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier.weight((1.0f))
        ) {
            Text(task.taskname, color = Color(mainremindercolour), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                task.taskdescription,
                color = Color(accentremindercolour),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Column(
            modifier = Modifier.weight((1.0f)),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                "${task.taskdate.format(formatter)}",
                color = Color(mainremindercolour),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(0.35f),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                if (allReminders.contains(task)) {
                    Button(
                        modifier = Modifier.weight(0.33f),
                        contentPadding = PaddingValues(5.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(confirmbutton)),

                        onClick = {
                            alterStatusType = "Complete"
                            isAlterReminderDialogOpen = true
                        }
                    ) {
                        Icon(
                            Icons.Outlined.Check,
                            contentDescription = "Tick Icon",
                            tint = Color(blackcolour),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    Button(
                        modifier = Modifier.weight(0.33f),
                        contentPadding = PaddingValues(5.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(mainbutton)),

                        onClick = {
                            isEditReminderDialogOpen = true
                        }
                    ) {
                        Icon(
                            Icons.Filled.Edit,
                            contentDescription = "Edit Icon",
                            tint = Color(blackcolour),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    Button(
                        modifier = Modifier.weight(0.33f),
                        contentPadding = PaddingValues(5.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(cancelbutton)),

                        onClick = {
                            alterStatusType = "Delete"
                            isAlterReminderDialogOpen = true
                        }
                    ) {
                        Icon(
                            Icons.Filled.Delete,
                            contentDescription = "Delete Icon",
                            tint = Color(blackcolour),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                } else {
                    Button(
                        modifier = Modifier.weight(0.5f),
                        contentPadding = PaddingValues(5.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(mainbutton)),

                        onClick = {
                            alterStatusType = "Return"
                            isAlterReminderDialogOpen = true
                        }
                    ) {
                        Icon(
                            Icons.Filled.Refresh,
                            contentDescription = "Undo Icon",
                            tint = Color(blackcolour),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    Button(
                        modifier = Modifier.weight(0.5f),
                        contentPadding = PaddingValues(5.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(cancelbutton)),

                        onClick = {
                            alterStatusType = "Delete"
                            isAlterReminderDialogOpen = true
                        }
                    ) {
                        Icon(
                            Icons.Filled.Delete,
                            contentDescription = "Delete Icon",
                            tint = Color(blackcolour),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                }

            }
        }
        // Passes the ability to close the dialog to the dialog itself
        fun closeAlterDialog() {
            isAlterReminderDialogOpen = false
        }
        // Runs the alter reminder dialog, for completing, deleting or returning a task (reassigning the list)
        if (isAlterReminderDialogOpen) {
            alterReminderDialog(task, ::closeAlterDialog, alterStatusType)
        }
        // Passes the ability to close the dialog to the dialog itself
        fun closeEditDialog() {
            isEditReminderDialogOpen = false
        }
        // Runs the delete reminder dialog
        if (isEditReminderDialogOpen) {
            editReminderDialog(task, ::closeEditDialog)
        }
    }
}

// A simplified version of the ReminderRow, minus the edit and delete buttons
@Composable
fun BasicReminderRow(task: Task, isItToday: Boolean) {
    var mainremindercolour: Long
    var accentremindercolour: Long

    // If reminder is in allReminders, the colours used will be purple if the task isn't due today and red if it is
    // Else, the reminder is in completedReminders, so the colours used will be green
    if (allReminders.contains(task)) {
        if (isItToday == true) {
            mainremindercolour = 0xFFD60000
            accentremindercolour = 0xFFFF0000
        } else {
            mainremindercolour = 0xFF800080
            accentremindercolour = 0xFFA100A1
        }
    } else {
        mainremindercolour = 0xFF45AD68
        accentremindercolour = 0xFF50C878
    }
    Row(
        modifier = Modifier.fillMaxWidth().background(color = Color(whitecolour), shape = RoundedCornerShape(20))
            .border(width = 3.5.dp, shape = RoundedCornerShape(20), color = Color(mainremindercolour)).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.weight((1.0f))
        ) {
            Text(task.taskname, color = Color(mainremindercolour), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                task.taskdescription,
                color = Color(accentremindercolour),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Column(
            modifier = Modifier.weight((1.0f)),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                "${task.taskdate.format(formatter)}",
                color = Color(mainremindercolour),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// Dialog to create new reminders
@Composable
fun addNewReminderDialog() = DialogWindow(
    title = "Add New Reminder",
    state = DialogState(width = 400.dp),
    onCloseRequest = { isAddReminderDialogOpen = false }
) {
    // Scroll variable
    val scrollState = rememberScrollState()

    // Gets the current date and splits it up into day, month and year to use as default values
    val currentdate = (LocalDate.now())
    val explodeddate = currentdate.toString().split("-").reversed()
    val currentday = explodeddate[0].toInt()
    val currentmonth = explodeddate[1].toInt()
    val currentyear = explodeddate[2].toInt()

    // Variables for the name and description of a new task
    var newtaskname by remember { mutableStateOf("") }
    var newtaskdescription by remember { mutableStateOf("") }

    // Variables for the day, month and year of the date for a new task
    // Default values are the day, month and year recorded on execution
    var newtaskday by remember { mutableStateOf("$currentday") }
    var newtaskmonth by remember { mutableStateOf("$currentmonth") }
    var newtaskyear by remember { mutableStateOf("$currentyear") }

    // Warning message variable
    var warningmessageenabled by remember { mutableStateOf(false) }

    // Name text field colour variables
    var namefocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var nameunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Day text field colour variables
    var dayfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var dayunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Month text field colour variables
    var monthfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var monthunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Year text field colour variables
    var yearfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var yearunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Code to add in new reminders
    Column(
        modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.weight(0.8f).verticalScroll(state = scrollState)
        ) {
            // Text fields to enter each value, that constantly update the remembered mutable variables
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),

                label = { Text("Name") },
                value = newtaskname,
                onValueChange = { newtaskname = it },

                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Color(namefocusedcolour),
                    unfocusedBorderColor = Color(nameunfocusedcolour),
                    focusedLabelColor = Color(namefocusedcolour),
                    unfocusedLabelColor = Color(nameunfocusedcolour)
                )
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),

                label = { Text("Description (Optional)") },
                value = newtaskdescription,
                onValueChange = { newtaskdescription = it }
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedTextField(
                    modifier = Modifier.weight(0.3f),

                    label = { Text("Day") },
                    value = "$newtaskday",
                    onValueChange = { newtaskday = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    maxLines = 1,

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(dayfocusedcolour),
                        unfocusedBorderColor = Color(dayunfocusedcolour),
                        focusedLabelColor = Color(dayfocusedcolour),
                        unfocusedLabelColor = Color(dayunfocusedcolour)
                    )
                )
                OutlinedTextField(
                    modifier = Modifier.weight(0.3f),

                    label = { Text("Month") },
                    value = "$newtaskmonth",
                    onValueChange = { newtaskmonth = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    maxLines = 1,

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(monthfocusedcolour),
                        unfocusedBorderColor = Color(monthunfocusedcolour),
                        focusedLabelColor = Color(monthfocusedcolour),
                        unfocusedLabelColor = Color(monthunfocusedcolour)
                    )
                )
                OutlinedTextField(
                    modifier = Modifier.weight(0.3f),

                    label = { Text("Year") },
                    value = "$newtaskyear",
                    onValueChange = { newtaskyear = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    maxLines = 1,

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(yearfocusedcolour),
                        unfocusedBorderColor = Color(yearunfocusedcolour),
                        focusedLabelColor = Color(yearfocusedcolour),
                        unfocusedLabelColor = Color(yearunfocusedcolour)
                    )
                )
            }
        }
        if (warningmessageenabled == true) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(color = Color(cancelbutton), shape = RoundedCornerShape(20))
                    .border(width = 3.5.dp, shape = RoundedCornerShape(20), color = Color(cancelbutton)).padding(5.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "All marked fields must be completed",
                    color = Color(whitecolour),
                    fontSize = 10.sp
                )
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                modifier = Modifier.weight(1.0f),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(confirmbutton)),

                onClick = {
                    if (newtaskname.isBlank()) {
                        namefocusedcolour = falsefocusedcolour
                        nameunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskday.isBlank()) {
                        dayfocusedcolour = falsefocusedcolour
                        dayunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskmonth.isBlank()) {
                        monthfocusedcolour = falsefocusedcolour
                        monthunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskyear.isBlank()) {
                        yearfocusedcolour = falsefocusedcolour
                        yearunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskname.isNotBlank() && newtaskday.isNotBlank() && newtaskmonth.isNotBlank() && newtaskyear.isNotBlank()) {
                        // Passes the dates to checkDate to see if they are within a correct range and then combine them and return
                        val newtaskdate = checkDate(newtaskday, newtaskmonth, newtaskyear)

                        val newReminder = Task("$newtaskname", "$newtaskdescription", newtaskdate)

                        allReminders.add(newReminder)
                        allReminders.saveToFile()

                        isAddReminderDialogOpen = false
                    } else {
                        warningmessageenabled = true
                    }
                }
            ) {
                Text("Add New Reminder", color = Color(whitecolour))
            }
            Button(
                modifier = Modifier.weight(1.0f),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(cancelbutton)),

                onClick = {
                    isAddReminderDialogOpen = false
                }
            ) {
                Text("Close", color = Color(whitecolour))
            }
        }
    }
}

// Dialog to delete individual reminders
@Composable
fun alterReminderDialog(task: Task, closeMe: () -> Unit, type: String) = DialogWindow(
    title = "$type Reminder",
    state = DialogState(width = 400.dp, height = 180.dp),
    onCloseRequest = { closeMe() }
) {
    val currentdate = LocalDate.now()

    // Scroll variable
    val scrollState = rememberScrollState()

    // Original task and index
    var originaltask by remember { mutableStateOf(task) }
    var originaltaskindex by remember { mutableStateOf(allReminders.indexOf(originaltask)) }

    // Colours to be used based on what action is being performed on the reminder
    var mainbuttoncolour by remember { mutableStateOf(confirmbutton) }
    var cancelbuttoncolour by remember { mutableStateOf(cancelbutton) }
    // Messages to be used based on what action is being performed on the reminder
    var warningmessage by remember { mutableStateOf("Are you sure you have completed this task?") }

    if (type == "Complete") {
        mainbuttoncolour = confirmbutton
        cancelbuttoncolour = cancelbutton
        originaltaskindex = allReminders.indexOf(originaltask)
        warningmessage = "Are you sure you have completed this task?"
    }
    if (type == "Delete") {
        mainbuttoncolour = cancelbutton
        cancelbuttoncolour = mainbutton
        originaltaskindex = allReminders.indexOf(originaltask)
        warningmessage = "Are you sure you want to delete this reminder?"
    }
    if (type == "Return") {
        mainbuttoncolour = mainbutton
        cancelbuttoncolour = cancelbutton
        originaltaskindex = completedReminders.indexOf(originaltask)
        warningmessage = "Are you sure you want to return this reminder?"
    }

    Column(
        modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.weight(0.8f).verticalScroll(state = scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ReminderRow to show task being deleted neatly and clearly
            if (currentdate >= task.taskdate) {
                BasicReminderRow(task, true)
            } else {
                BasicReminderRow(task, false)
            }
        }
        Column(

        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(color = Color(mainbuttoncolour), shape = RoundedCornerShape(20))
                    .border(width = 2.dp, shape = RoundedCornerShape(20), color = Color(mainbuttoncolour))
                    .padding(5.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "$warningmessage",
                    color = Color(whitecolour),
                    fontSize = 15.sp
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1.0f),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(mainbuttoncolour)),

                    onClick = {
                        if (type == "Complete") {
                            // Finds the index of the task in the allReminders list and deletes it and adds it to completedReminders
                            val copiedReminder = allReminders[originaltaskindex].copy()
                            allReminders.removeAt(originaltaskindex)
                            allReminders.saveToFile()

                            completedReminders.add(copiedReminder)
                            completedReminders.saveToCompletedFile()
                        }
                        if (type == "Delete") {
                            // Finds the index of the task from either list and deletes it
                            if (allReminders.contains(task)) {
                                val index = allReminders.indexOf(task)
                                allReminders.removeAt(index)

                                allReminders.saveToFile()
                            }
                            if (completedReminders.contains(task)) {
                                val index = completedReminders.indexOf(task)
                                completedReminders.removeAt(index)

                                completedReminders.saveToFile()
                            }
                        }
                        if (type == "Return") {
                            // Finds the index of the task in the completedReminders list and deletes it and adds it to allReminders list
                            val copiedReminder = completedReminders[originaltaskindex].copy()
                            completedReminders.removeAt(originaltaskindex)
                            completedReminders.saveToCompletedFile()

                            allReminders.add(copiedReminder)
                            allReminders.saveToFile()
                        }
                        closeMe()
                    }
                ) {
                    Text("$type Reminder", color = Color(whitecolour))
                }
                Button(
                    modifier = Modifier.weight(1.0f),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(cancelbuttoncolour)),

                    onClick = {
                        closeMe()
                    }
                ) {
                    Text("Cancel", color = Color(whitecolour))
                }
            }
        }
    }
}

// Dialog to edit any individual task
@Composable
fun editReminderDialog(task: Task, closeMe: () -> Unit) = DialogWindow(
    title = "Edit Reminder",
    state = DialogState(width = 400.dp),
    onCloseRequest = { closeMe() }
) {
    // Scroll variable
    val scrollState = rememberScrollState()

    // Gets the index of the original task in allReminders list
    val originaltask = task
    val originaltaskindex = allReminders.indexOf(originaltask)

    // Variables for the name and description of the task, with the original values
    var newtaskname by remember { mutableStateOf("${originaltask.taskname}") }
    var newtaskdescription by remember { mutableStateOf("${originaltask.taskdescription}") }

    // Seperates the original date of the task into day, month and year to be used as default values for variables
    val explodeddate = originaltask.taskdate.toString().split("-").reversed()
    val currentday = explodeddate[0]
    val currentmonth = explodeddate[1]
    val currentyear = explodeddate[2]

    // Variables for the day, month and year of the date for the edited task
    // Default values are the day, month and year recorded from original task
    var newtaskday by remember { mutableStateOf("$currentday") }
    var newtaskmonth by remember { mutableStateOf("$currentmonth") }
    var newtaskyear by remember { mutableStateOf("$currentyear") }

    // Warning message variable
    var warningmessageenabled by remember { mutableStateOf(false) }

    // Name text field colour variables
    var namefocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var nameunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Day text field colour variables
    var dayfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var dayunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Month text field colour variables
    var monthfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var monthunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    // Year text field colour variables
    var yearfocusedcolour by remember { mutableStateOf(truefocusedcolour) }
    var yearunfocusedcolour by remember { mutableStateOf(trueunfocusedcolour) }

    Column(
        modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.weight(0.8f).verticalScroll(state = scrollState)
        ) {
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),

                label = { Text("Name") },
                value = newtaskname,
                onValueChange = { newtaskname = it },

                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Color(namefocusedcolour),
                    unfocusedBorderColor = Color(nameunfocusedcolour),
                    focusedLabelColor = Color(namefocusedcolour),
                    unfocusedLabelColor = Color(nameunfocusedcolour)
                )
            )
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),

                label = { Text("Description (Optional)") },
                value = newtaskdescription,
                onValueChange = { newtaskdescription = it }
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedTextField(
                    modifier = Modifier.weight(1f),

                    label = { Text("Day") },
                    value = "$newtaskday",
                    onValueChange = { newtaskday = it },

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(dayfocusedcolour),
                        unfocusedBorderColor = Color(dayunfocusedcolour),
                        focusedLabelColor = Color(dayfocusedcolour),
                        unfocusedLabelColor = Color(dayunfocusedcolour)
                    )
                )
                OutlinedTextField(
                    modifier = Modifier.weight(1f),

                    label = { Text("Month") },
                    value = "$newtaskmonth",
                    onValueChange = { newtaskmonth = it },

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(monthfocusedcolour),
                        unfocusedBorderColor = Color(monthunfocusedcolour),
                        focusedLabelColor = Color(monthfocusedcolour),
                        unfocusedLabelColor = Color(monthunfocusedcolour)
                    )
                )
                OutlinedTextField(
                    modifier = Modifier.weight(1f),

                    label = { Text("Year") },
                    value = "$newtaskyear",
                    onValueChange = { newtaskyear = it },

                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(yearfocusedcolour),
                        unfocusedBorderColor = Color(yearunfocusedcolour),
                        focusedLabelColor = Color(yearfocusedcolour),
                        unfocusedLabelColor = Color(yearunfocusedcolour)
                    )
                )
            }
        }
        if (warningmessageenabled == true) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(color = Color(cancelbutton), shape = RoundedCornerShape(20))
                    .border(width = 3.5.dp, shape = RoundedCornerShape(20), color = Color(cancelbutton)).padding(5.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "All marked fields must be completed",
                    color = Color(whitecolour),
                    fontSize = 10.sp
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                modifier = Modifier.weight(1.0f),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(confirmbutton)),

                onClick = {
                    if (newtaskname.isBlank()) {
                        namefocusedcolour = falsefocusedcolour
                        nameunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskday.isBlank()) {
                        dayfocusedcolour = falsefocusedcolour
                        dayunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskmonth.isBlank()) {
                        monthfocusedcolour = falsefocusedcolour
                        monthunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskyear.isBlank()) {
                        yearfocusedcolour = falsefocusedcolour
                        yearunfocusedcolour = falseunfocusedcolour
                    }
                    if (newtaskname.isNotBlank() && newtaskday.isNotBlank() && newtaskmonth.isNotBlank() && newtaskyear.isNotBlank()) {
                        // Passes the dates to checkDate to see if they are within a correct range and then combine them and return
                        val newtaskdate = checkDate(newtaskday, newtaskmonth, newtaskyear)

                        // Overrides the original task with a copy, then changes the values to the new ones
                        allReminders[originaltaskindex] = task.copy(
                            taskname = newtaskname,
                            taskdescription = newtaskdescription,
                            taskdate = newtaskdate
                        )
                        allReminders.saveToFile()

                        closeMe()
                    } else {
                        warningmessageenabled = true
                    }
                }
            ) {
                Text("Update Reminder", color = Color(whitecolour))
            }
            Button(
                modifier = Modifier.weight(1.0f),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(cancelbutton)),

                onClick = {
                    closeMe()
                }
            ) {
                Text("Close", color = Color(whitecolour))
            }
        }
    }
}

fun main() = singleWindowApplication(
    title = "Reminders"
) {
    allReminders.loadFromFile()
    completedReminders.loadFromCompletedFile()
    App()
}

/**
 * Load object data from the tasks JSON file into a list
 */
inline fun <reified T : Any> MutableList<T>.loadFromFile(): Boolean {
    return try {
        val dataFile = File(remindersDataFilePath)
        val jsonString = dataFile.readText()
        val peopleData = Json.decodeFromString<List<T>>(jsonString)
        this.clear()
        this.addAll(peopleData)
        true
    } catch (e: Exception) {
        // File is missing or corrupt
        false
    }
}

/**
 * Save a list of objects to the tasks file in JSON format
 */
inline fun <reified T : Any> MutableList<T>.saveToFile(): Boolean {
    val jsonBuild = Json { prettyPrint = true }
    return try {
        val jsonString = jsonBuild.encodeToString(this)
        val dataFile = File(remindersDataFilePath)
        dataFile.writeText(jsonString)
        true
    } catch (e: Exception) {
        // File could not be written
        false
    }
}

/**
 * Load object data from the completed tasks JSON file into a list
 */
inline fun <reified T : Any> MutableList<T>.loadFromCompletedFile(): Boolean {
    return try {
        val dataFile = File(completedDataFilePath)
        val jsonString = dataFile.readText()
        val peopleData = Json.decodeFromString<List<T>>(jsonString)
        this.clear()
        this.addAll(peopleData)
        true
    } catch (e: Exception) {
        // File is missing or corrupt
        false
    }
}

/**
 * Save a list of objects to the completed tasks file in JSON format
 */
inline fun <reified T : Any> MutableList<T>.saveToCompletedFile(): Boolean {
    val jsonBuild = Json { prettyPrint = true }
    return try {
        val jsonString = jsonBuild.encodeToString(this)
        val dataFile = File(completedDataFilePath)
        dataFile.writeText(jsonString)
        true
    } catch (e: Exception) {
        // File could not be written
        false
    }
}